The testing could not be done due to large amount taken for training.
Report will be mailed shortly and will be uploaded to out project link https://github.com/Horopter/ShortTextClassification

Sincerely,
	Madhuresh Bhattacharya
	Santosh Desai