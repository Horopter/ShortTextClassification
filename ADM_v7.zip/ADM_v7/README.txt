Refer to the README.html inside the src folder
Project link  : https://github.com/Horopter/ShortTextClassification

Important note :  Topic drift could not be made anytime, so it has not been implemented from he paper

Sincerely,
	Santosh Desai (2017H1030130P)