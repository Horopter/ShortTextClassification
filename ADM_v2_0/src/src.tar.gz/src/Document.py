import re

class Document():
	line=""
	def __init__(self, s_line):
		self.line=s_line

